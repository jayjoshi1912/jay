#include<stdio.h>

void main()
{
	int i,a;
	for(i=1;i<=5;i++)
	{
		for(a=1;a<=i;a++)
		{
			printf("%d",a);
		}
		printf("\n");
	}
}