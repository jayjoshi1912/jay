#include<stdio.h>

void main()
{
	int i,a;
	for(i=1;i<=10;i++)
	{
		for(a=1;a<=i;a++)
		{
			printf("*");
		p
}