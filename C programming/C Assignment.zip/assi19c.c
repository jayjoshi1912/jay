#include<stdio.h>

void main()
{
	int num=100;
	do
	{
		printf("\n%d",num);
		num--;
	}
	while(num>=81);

}