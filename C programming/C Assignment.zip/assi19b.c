#include<stdio.h>

void main()
{
	int num=51;
	while(num<=60)
	{
		printf("\n%d",num);
		num++;
	}
}