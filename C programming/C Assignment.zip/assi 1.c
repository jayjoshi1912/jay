#include <stdio.h>

void main()
{
	char birthdate[10];
	int age;
	char name[50] ,addrese[50];
	printf("\n-----------------------");
	printf("\nNAME IS     : ");
	scanf("%s",&name);
	printf("-----------------------");
	printf("\nBIRTHDATE   : ");
	scanf("%s",&birthdate);
	printf("-----------------------");
	printf("\nAGE         : ");
	scanf("%d",&age);
	printf("-----------------------");
	printf("\nADDRESE     : ");
	scanf("%s",&addrese);
}