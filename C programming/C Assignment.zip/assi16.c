#include<stdio.h>
void main()
{
	switch(1)
	{
		case  1  : printf("\nMonday\n");
		case  2  : printf("Tuesday\n");
		case  4  : printf("Wednesday\n");		  		
		case  5  : printf("Thursday\n");
		case  6  : printf("Friday\n");
		case  7  : printf("Saturday\n");
		
	}
}