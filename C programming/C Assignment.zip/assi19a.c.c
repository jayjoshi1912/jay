#include<stdio.h>

void main()
{
	int number;
	for(number=1; number<=10; number++)
	{
		printf("\n%d",number);
	}
	
	
}      
	 	