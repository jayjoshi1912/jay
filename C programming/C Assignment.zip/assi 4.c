#include<stdio.h>

void main()
{
	float radius,area;
	printf("\n ENTER THE RADIUS OF CIRCLE  : ");
	scanf("%f",&radius);
	
	area=3.14*radius*radius;
	printf("\n AREA OF CIRCLE : %.2f",area);
	
	
	
	
}