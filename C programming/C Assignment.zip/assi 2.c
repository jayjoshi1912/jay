#include<stdio.h>

void main()
{
	int a=10 , b=11 ;
	printf("\nA\t\t\t=%d \nB\t\t\t=%d",a,b);
	printf("\naddition is \t\t=%d",a+b);
	printf("\nsubtraction is\t\t=%d",a-b);
	printf("\nmultiplication is \t=%d",a*b);
	printf("\ndivision is \t\t=%f",a/(float)b);
}