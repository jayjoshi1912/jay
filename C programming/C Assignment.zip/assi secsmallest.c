#include<stdio.h>

void main()
{
	
	int array[100],n,i,smallest ,secondsmallest;
	
	printf("how many elements  do you want to enter : ");
	scanf("%d",&n);
	printf("\nEnter %d Elements",n);
	for (i=0;i<n;i++)
	{
		scanf("%d",&array[i]);
		if(array[0]<array[1])
	    {
	    	smallest = array[0];
	    	secondsmallest = array[1];
	    }
	    else 
	    {
	    	smallest = array[1];
	    	secondsmallest = array[0];
		}
	}
	for(i=2;i<n;i++)
	{
		if(array[i] < smallest)
		{
			secondsmallest = smallest;
			smallest = array[i];
		}
		else if (array[i]< secondsmallest)
		{
			secondsmallest = array[i];
		}
	}
	printf("\nsecond smallest element is %d",secondsmallest);
}