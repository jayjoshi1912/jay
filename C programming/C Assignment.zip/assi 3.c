#include<stdio.h>

void main()
{
	int a=12 , b=21 ;
	printf("\nA\t\t=%d \nB\t\t=%d",a,b);
	printf("\nsquare A\t=%d",a*a);
	printf("\nsquare B\t=%d",b*b);
	printf("\ncube A\t\t=%d",a*a*a);
	printf("\ncube B\t\t=%d",b*b*b);
}